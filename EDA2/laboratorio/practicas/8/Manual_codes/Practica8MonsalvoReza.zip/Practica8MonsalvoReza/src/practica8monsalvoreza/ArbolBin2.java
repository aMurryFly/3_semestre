/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica8monsalvoreza;

/**
 *
 * @author HP14
 */
import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @author HP14
 */
public class ArbolBin2 {

    Nodo2 root;
    public ArbolBin2(){
        root=null;
    }
    public ArbolBin2(int val){
        root=new Nodo2(val);
    }
    public ArbolBin2(Nodo2 root){
        this.root=root;
    }
    
    public void add(Nodo2 padre, Nodo2 hijo, int lado){
        if(lado==0){
            padre.setIzq(hijo);
            
        
        }else{
            padre.setDer(hijo);
        }   
    }
    
    public void add(int lado,Nodo2 agregado, Nodo2 inicio){
        if(lado==0){
            if(inicio.izq==null){
                agregado.setFather(inicio);
                inicio.setIzq(agregado);
                
            }else if(inicio.der==null){
                inicio.setDer(agregado);
            }else{
                add(0,agregado,inicio.izq);       
            }
        }
        else{
            if(inicio.izq==null){
                agregado.setFather(inicio);
                inicio.setIzq(agregado);
            }else if(inicio.der==null){
                inicio.setDer(agregado);
            }else{
                add(1,agregado,inicio.der);       
            }
        }
    }
    public void delete(int delete){
        Nodo2 r=root;
        Queue<Nodo2> queue = new LinkedList();
        if(r!=null){
            queue.add(r);
            while(!queue.isEmpty()){
                r=(Nodo2)queue.poll();
                visit(r);
                if(r.izq!=null) 
                    queue.add(r.izq);
                if(r.der!=null)
                    queue.add(r.der);
                if(r.valor==delete){
                    erase(r);
                
                }
            }
        
        }
    }
    public void erase(Nodo2 borrar){
        //Nodo hoja
        if(borrar.izq==null&&borrar.der==null){
            if(borrar.padre.izq.valor==borrar.valor){
                borrar.padre.izq=null;
                
            }else if(borrar.padre.der.valor==borrar.valor){
                borrar.padre.der=null;
                
            }
        }
        //Nodo si tiene un nodo en la izquierda
        else if(borrar.izq!=null&&borrar.der==null){
            if(borrar.padre!=null){
                if(borrar.padre.izq.valor==borrar.valor){
                    borrar.izq.padre=borrar.padre;

                }else if(borrar.padre.der.valor==borrar.valor){
                    borrar.izq.padre=borrar.padre;

                }
            }else{
                erase(borrar.izq);
            }
        }
        //nodo si tiene un nodo en la derecha
        else if(borrar.izq==null&&borrar.der!=null){
            if(borrar.padre!=null){
                if(borrar.padre.der.valor==borrar.valor){
                    borrar.der.padre=borrar.padre;


                }else if(borrar.padre.der.valor==borrar.valor){
                    borrar.der.padre=borrar.padre;

                }
            }
            erase(borrar.der);
        }
        //Nodo si tiene 2 nodos hijos
        else if(borrar.izq!=null&&borrar.der!=null){
            if(borrar.padre!=null){
                if(borrar.padre.der.valor==borrar.valor){
                    erase(borrar.izq);


                }else if(borrar.padre.der.valor==borrar.valor){
                    erase(borrar.der);

                }
            
            
            }
            else{
                erase(borrar.izq);
            }
        }
    
    }
    
    protected void visit(Nodo2 n){
        System.out.println(n.valor+" ");
    
    }
    //BFS
    public void breadthFirst(){
        Nodo2 r=root;
        Queue<Nodo2> queue = new LinkedList();
        if(r!=null){
            queue.add(r);
            while(!queue.isEmpty()){
                r=(Nodo2)queue.poll();
                visit(r);
                if(r.izq!=null) 
                    queue.add(r.izq);
                if(r.der!=null)
                    queue.add(r.der);
            
            }
        
        }

    }
    
    //Notaciones
    public void prefija(Nodo2 inicio){
        
        visit(inicio);
        if(inicio.izq!=null){
            prefija(inicio.izq);
        }
        if(inicio.der!=null){
            prefija(inicio.der);
        }
    }
    
    public void infija(Nodo2 inicio){
        
        
        if(inicio.izq!=null){
            prefija(inicio.izq);
        }
        visit(inicio);
        if(inicio.der!=null){
            prefija(inicio.der);
        }
    }
    
    public void posfija(Nodo2 inicio){
        
        
        if(inicio.izq!=null){
            prefija(inicio.izq);
        }
        if(inicio.der!=null){
            prefija(inicio.der);
        }
        visit(inicio);
    }

}


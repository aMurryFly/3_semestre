/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica8monsalvoreza;

import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @author edaII05alu33
 */
public class ArbolBin {
    Nodo root;
    
    public ArbolBin(){
        root=null;
    }
    public ArbolBin(int val){
        root=new Nodo(val);
    }
    public ArbolBin(Nodo root){
        this.root=root;
        root.izq.padre=root;
        root.der.padre=root;

    }
    
    public void add(Nodo padre, Nodo hijo, int lado){
        if(lado==0){
            padre.setIzq(hijo);
            hijo.padre=padre;
        }else{
            padre.setDer(hijo);
            hijo.padre=padre;
        }     
    }
    
    
    
    protected void visit(Nodo n){
        System.out.println(n.valor+" ");   
    }
    
    public void breadthFirst(){
        Nodo r=root;
        Queue<Nodo> queue = new LinkedList();
        if(r!=null){
            queue.add(r);
            while(!queue.isEmpty()){
                r=(Nodo)queue.poll();
                visit(r);
                if(r.izq!=null) 
                    queue.add(r.izq);
                if(r.der!=null)
                    queue.add(r.der);
            
            }
        
        }
    
    }
    
    
    public int busqueda(int valor){
        Nodo r=root;
        Queue<Nodo> queue = new LinkedList();
        
        if(r!=null){
            queue.add(r);
            while(!queue.isEmpty()){
                r=(Nodo)queue.poll();               
                if(r.izq!=null) 
                    queue.add(r.izq);
                if(r.der!=null)
                    queue.add(r.der);
                
                if(r.valor==valor){
                   
                    return 1;                   
                }
            } 
        }
         return 0;
    }
    
    
    public Nodo busqueda2(int valor){
        Nodo r=root;
        Queue<Nodo> queue = new LinkedList();
       
        
        if(r!=null){
            queue.add(r);
            while(!queue.isEmpty()){
                r=(Nodo)queue.poll();
         
                
                if(r.izq!=null) 
                    queue.add(r.izq);
                if(r.der!=null)
                    queue.add(r.der);
                
                if(r.valor==valor){
                    
                    
                    return r;                   
                }
            } 
        }
         return null;
    }


    public void eliminar(int valor){
        Nodo n;
        n=busqueda2(valor);
        
        if(n!=null){
            //3 casos
            //Si no tiene hijos
            if(n.izq==null&& n.der==null){
                eliminar1(n);
            }else if (n.izq!=null&& n.der==null){   //si tiene un hijo
                eliminar2(n);
            }else if (n.izq==null&& n.der!=null){
                eliminar2(n);
            }else if(n.izq!=null&& n.der!=null){ //si tiene dos hijos
                eliminar3(n);
            
            }
            
            
            
            
      
        }
   
    }
    
    public void eliminar1(Nodo n){
        if(n.padre!=null){
        Nodo iz=n.padre.izq;
        Nodo der=n.padre.der;
        
        if(iz==n){
            
            n.padre.izq=null;
            System.out.println("Eliminado");
        }
        if(der==n){
            n.padre.der=null;
            System.out.println("Eliminado");
        }
    
        }
        
        //Eliminar raiz
        if(n==this.root){
            n=null;
        }
        
        
        
    }
    
    public void eliminar2(Nodo n){
         if(n.padre!=null){
            Nodo iz=n.padre.izq;
            Nodo der=n.padre.der;

            Nodo hijo;
            //Encontrar al nodo hijo
            if(n.izq!=null){
                hijo=n.izq;
            }else{
                hijo=n.der;
            }

            //Eliminar elemento
            if(iz==n){               
                n.padre.izq=hijo;
                n.izq=n.der=n.padre=null;
                n=null;
                System.out.println("Eliminado");
            }
            if(der==n){
                n.padre.der=hijo;
                n.izq=n.der=n.padre=null;
                n=null;
                System.out.println("Eliminado");
            }
    
        }
         
         if(n==this.root){
              Nodo hijo;
            //Encontrar al nodo hijo
            if(n.izq!=null){
                hijo=n.izq;
            }else{
                hijo=n.der;
            }
            
            this.root=hijo;
            n=null;
            System.out.println("Eliminado");
        }
        
        
        
        
    }
  
    public void eliminar3(Nodo n){
        System.out.println("eliminar3 ");
        if(n.padre!=null){
            
            Nodo iz=n.padre.izq;
            Nodo der=n.padre.der;
            
            Nodo mayorM;            
            mayorM=(minimo(n));
          
            if(iz==n){               
                n.padre.izq=mayorM;
                n=null;
                System.out.println("Eliminado");
            }else if(der==n){
                n.padre.der=mayorM;          
                n=null;
                System.out.println("Eliminado");
            }

        }else{
            Nodo mayorM=(minimo(n));
            this.root=mayorM;
    
        }
           
        
        
        
    }
    
    
    public Nodo minimo(Nodo n){
        Nodo actual=n;
  
        do{
  
            while(actual.izq!=null){
                actual=actual.izq;
            }
             while(actual.der!=null){
                actual=actual.der;
            }
        
        }while(actual.der!=null && actual.izq!=null);
        
        
        
            
        Nodo iz=actual.padre.izq;
        Nodo der=actual.padre.der;

        
        if(iz==actual){
            actual.padre.izq=null;
        }else{
            actual.padre.der=null;
        }
                actual.izq=n.izq;
                actual.der=n.der;
                
                if(n.padre!=null){
                actual.padre=n.padre;
                }else{
                actual.padre=null;
                }
                
        return actual;

        
        
    }
    
    public Nodo maximo(Nodo n){
        Nodo actual=n;
        while(actual.der!=null){
            actual=actual.der;
        }
        

        return actual;
        
    }
     public void preorden(){
        System.out.println("Notación prefija ");
        preorden1(this.root);
    }
    
    public void preorden1(Nodo raiz){
        Nodo r=raiz;
        Queue<Nodo> queue = new LinkedList();  
        
        if(r!=null){
            queue.add(r);            
            while(!queue.isEmpty()){
                r=(Nodo)queue.poll();
                visit(r);
                if(r.izq!=null){
                    
                    preorden1(r.izq);
                }
                if(r.der!=null){
                   
                    preorden1(r.der);
                }
                    
                
                
            }
        }
        
        
        
    }
    
    public void inorden(){
    System.out.println("Notación sufija");
    inorden1(this.root);
    }
   
    public void inorden1(Nodo raiz){       
        Nodo r=raiz;          
        Queue<Nodo> queue = new LinkedList();    
        if(r!=null){
            queue.add(r);            
            while(!queue.isEmpty()){
                r=(Nodo)queue.poll();
                
                if(r.izq!=null){                   
                    inorden1(r.izq);
                }               
                visit(r);                
                if(r.der!=null){   
                    inorden1(r.der);
                }
            
            }
        }
    }
   
    public void postorden(){
    System.out.println("Notación posfija");
    postorden1(this.root);
    }
     
     public void postorden1(Nodo raiz){       
        Nodo r=raiz;          
        Queue<Nodo> queue = new LinkedList();    
        if(r!=null){
            queue.add(r);            
            while(!queue.isEmpty()){
                r=(Nodo)queue.poll();
                
                if(r.izq!=null){                   
                    postorden1(r.izq);
                }               
                               
                if(r.der!=null){   
                    postorden1(r.der);
                }
                visit(r); 
            
            }
        }
    }
    
    

    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica8monsalvoreza;

/**
 *
 * @author HP14
 */
public class Nodo2 {
    int valor;
	Nodo2 izq=null;
	Nodo2 der=null;
        Nodo2 padre=null;
	public Nodo2(){
		izq=der=padre=null;
	}


	public Nodo2(int data){
		this(data,null,null);
	}

	public Nodo2(int data, Nodo2 lt, Nodo2 rt){
		valor=data;
		izq=lt;
		der=rt;
	}
	public void setIzq(Nodo2 izq){
		this.izq=izq;
	}
	public void setDer(Nodo2 der){
		this.der=der;
	}
        public void setFather(Nodo2 up){
                this.padre=up;
        }
}


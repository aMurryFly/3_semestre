/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica8monsalvoreza;

/**
 *
 * @author HP14
 */
import java.util.Scanner;
/**
 *
 * @author Segarecha
 */
public class Menu {
    public static void main(String []args){
        int op;
        int op2;
        
        int valor;
        int ind;
        
        Scanner sc= new Scanner(System.in);
        System.out.println("\tBienvenido\n");
        
        Nodo n1, n2,n3;
        
        do{
            System.out.println("\tIngrese el tipo de árbol con el que deseé trabajar.");
            System.out.print("\t1)Árbol Binario\n\t3)Árbol Binario de búsqueda\n\t3)Salir\n\tOpción: ");
            op=sc.nextInt();
            
            switch (op) {
                case 1:
                    ArbolBin2 arbol= new ArbolBin2();
                    do{
                        System.out.println("Arbol Binario");
                        
                        System.out.println("\t1)Agregar\n\t2)Eliminar\n\t3)BFS\n\t4)Notación prefija\n\t5)Notación Infija\n\t6)Notación Posfija\n\t7)Salir");
                        System.out.print("\tOpción: ");
                        op2=sc.nextInt();
                        switch (op2) {
                            case 1:
                                System.out.println("Agregar nodo");
                                System.out.println("Ingrese el número del nodo");
                                valor=sc.nextInt();

                                if(arbol.root!=null){
                                    System.out.println("Derecha o derecha (0/1)");
                                    ind=sc.nextInt();
                                    arbol.add(ind,new Nodo2(valor),arbol.root);
  

                                }else{
                                    arbol=new ArbolBin2(valor);
                                }
                                break;
                            case 2:
                                System.out.println("Eliminar nodo");
                                if(arbol.root!=null){
                                    System.out.println("Ingrese el nombre del nodo a eliminar");
                                    valor=sc.nextInt();
                                    arbol.delete(valor);
                                }else{
                                    System.out.println("Arbol vacío");
                                }
                                break;
                            case 3:
                                System.out.println("BFS");
                                arbol.breadthFirst();
                                break;
                            case 4:
                                System.out.println("Notación prefija");
                                arbol.prefija(arbol.root);
                                break;
                            case 5:
                                System.out.println("Notación infija");
                                arbol.infija(arbol.root);
                                break;
                            case 6:
                                System.out.println("Notación posfija");
                                arbol.posfija(arbol.root);
                                break;
                            case 7:
                                System.out.println("Se ha salido de la opción");
                                break;
                            default:
                                System.out.println("Opción inválida");
                        }
                    }while(op2!=7);
                    break;
                    
                case 2:
                     ArbolBinBusqueda arbol2= new ArbolBinBusqueda();
                    do{
                        System.out.println("Árbol binario de búsqueda");
                        System.out.println("\t1)Agregar\n\t2)Eliminar\n\t3)Buscar\n\t4)BFS\n\t5)Notación prefija\n\t6)Notación Infija\n\t7)Notación Posfija\n\t8)Salir");
                        System.out.print("\tOpción: ");
                        op2=sc.nextInt();

                        switch (op2) {
                            case 1:
                                
                                System.out.println("Agregar nodo");
                                System.out.println("Ingrese el número del nodo");
                                valor=sc.nextInt();
        
                                if(arbol2.root!=null){                                  
                                    arbol2.add(new Nodo(valor));  
                                }else{
                                    arbol2=new ArbolBinBusqueda(valor);
                                }
                                break;
                           
                            case 2:
                                System.out.println("Eliminar nodo");
                                
                                if(arbol2.root!=null){
                                    System.out.println("Ingrese el nombre del nodo a eliminar");
                                    valor=sc.nextInt();
                                    arbol2.eliminar(valor);

                                }else{
                                    System.out.println("Arbol vacío");
                                }
                                break;
                            case 3:
                                System.out.println("Buscar");
                                System.out.println("Ingrese el nombre del nodo a buscar");
                                valor=sc.nextInt();
                                if(arbol2.busqueda(valor)){
                                   System.out.println("El nodo "+valor+" sí se encuentra"); 
                                }else{
                                    System.out.println("El nodo "+valor+" no se encuentra"); 
                                }                   
                                break;
                            case 4:
                                System.out.println("Imprimir");
                                arbol2.breadthFirst();                               
                                break;
                            case 5:
                                
                                arbol2.preorden();
                                break;
                            case 6:
                                 
                                 arbol2.inorden();
                            case 7:
                                 
                                 arbol2.postorden();
                            case 8:
                                System.out.println("Se ha salido de la opción");
                                break;
                            default:
                                System.out.println("Opción inválida");
                        }
                    }while(op2!=8);
                    break;
                    
                case 3:
                    System.out.println("Hasta luego");
                default:
                    System.out.println("Opción no válida");
            }
            
            
        
        }while(op!=3);
    
    
    }
}


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica8monsalvoreza;

/**
 *
 * @author Melissa Monsalvo
 */
public class Ejercicio1 {
    public static void main(String args[]){
        
          System.out.println("Arbol binario");
		ArbolBin arbol;
		Nodo n7=new Nodo(7);
		Nodo n9=new Nodo(9);
		Nodo n1=new Nodo(1,n7,n9);
		Nodo n15=new Nodo(15);
		Nodo n8=new Nodo(8);
		Nodo n4=new Nodo(4);
		Nodo n2=new Nodo(2);
		Nodo n16=new Nodo(16);
		Nodo n3=new Nodo(3);
		arbol=new ArbolBin(n1);
		arbol.add(n7,n15,0);
		arbol.add(n7,n8,1);
		arbol.add(n9,n4,0);
		arbol.add(n9,n2,1);
		arbol.add(n15,n16,1);
		arbol.add(n8,n3,0);
                arbol.breadthFirst();
                
                
 
                Nodo n20=new Nodo(20);
		Nodo n21=new Nodo(21);
		Nodo n22=new Nodo(22);
                Nodo n23=new Nodo(23);
		Nodo n24=new Nodo(24);
		Nodo n25=new Nodo(25);
                
                Nodo n26=new Nodo(26);
		Nodo n27=new Nodo(27);
		Nodo n28=new Nodo(28);
                Nodo n29=new Nodo(29);
		Nodo n30=new Nodo(30);
		Nodo n31=new Nodo(23);
                
                System.out.println("Arbol binario de busqueda");
                ArbolBinBusqueda arbol1 = new ArbolBinBusqueda(n26);
             
                arbol1.add(n22);
                arbol1.add(n29);
                arbol1.add(n20);
                arbol1.add(n24);
                arbol1.add(n21);
                arbol1.add(n23); 
                arbol1.breadthFirst();
                
                //arbol1.busqueda(21);
                //arbol1.busqueda(25);
                System.out.println("Notaciones: ");
                arbol1.preorden();
                arbol1.inorden();
                arbol1.postorden();
                System.out.println("Nodos: "+arbol1.numNodos());
                System.out.println("Altura: "+arbol1.altura());
                System.out.println("Es balanceado: "+arbol1.esBalanceado());
                
                System.out.println("Eliminar");
                arbol1.eliminar(22);
                arbol1.breadthFirst();
                

	}
}
